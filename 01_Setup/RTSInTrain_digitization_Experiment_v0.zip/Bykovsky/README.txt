RTSInTrain - Thaw Slump Digitization Experiment
Please fill the Shapefile with polygons of all visible thaw slumps.
contact:Ingmar Nitze - ingmar.nitze@awi.de


Datasets:

1. Planet Scope Orthotile
SR: 3.12.5 m
Bands: 4
1: Blue, 2: Green, 3: Red, 4: NIR

2. Sentinel-2
SR: 10 m (max 10m, some bands 20m)
Bands: 1:'B2', 2:'B3', 3:'B4', 4:'B5', 5:'B6', 6:'B7', 7:'B8', 8:'B8A', 9:'B11', 10:'B12'
https://developers.google.com/earth-engine/datasets/catalog/COPERNICUS_S2

3. Landsat-8
SR: 15 m (max 15m pan, rest 30m)
Bands: 1:'B2', 2:'B3', 3:'B4', 4:'B5', 5:'B6', 6:'B7', 7:'B8'
https://developers.google.com/earth-engine/datasets/catalog/LANDSAT_LC08_C02_T1_TOA

4. ArcticDEM Mosaic
SR: 2m